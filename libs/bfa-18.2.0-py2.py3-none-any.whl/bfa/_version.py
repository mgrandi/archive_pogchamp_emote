"""
Provides bfa version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update bfa` to change this file.

from incremental import Version

__version__ = Version('bfa', 18, 2, 0)
__all__ = ["__version__"]
